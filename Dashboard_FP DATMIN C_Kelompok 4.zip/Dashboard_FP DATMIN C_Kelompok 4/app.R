options(repos = c(CRAN = "https://cran.rstudio.com"))

install.packages(c("shiny", "shinydashboard", "ggplot2", "dplyr", "corrplot", 
                   "GGally", "plotly", "shinythemes", "moments", 
                   "shinyDashboardThemes", "slickR", "dashboardthemes", "base64enc"))

library(shiny)
library(shinydashboard)
library(ggplot2)
library(dplyr)
library(corrplot)
library(GGally)
library(plotly)
library(moments)
library(dashboardthemes)
library(slickR)
library(base64enc)

# Load the dataset
data <- read.csv("breast-cancer.csv")

# Define UI
ui <- dashboardPage(
  dashboardHeader(title = "Breast Cancer Analysis"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Home", tabName = "home", icon = icon("home")),
      menuItem("Description", tabName = "description", icon = icon("info-circle")),
      menuItem("Summary", tabName = "summary", icon = icon("list-alt")),
      menuItem("Visualizations", tabName = "visualizations", icon = icon("bar-chart")),
      menuItem("Interactive Scatter Plot", tabName = "scatter_plot"),
      menuItem("Best Methods", tabName = "best_methods", icon = icon("tasks")),
      menuItem("Authors", tabName = "authors", icon = icon("users"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "home",
              fluidRow(
                box(
                  title = "Welcome",
                  status = "primary",
                  solidHeader = TRUE,
                  width = 12,
                  div(imageOutput("img1"), style = "text-align:center;",
                      style = "margin-bottom: -170px"),
                  h3("Breast Cancer Data Analysis"),
                  p("Breast cancer is the most common cancer amongst women in the world. 
                   It accounts for 25% of all cancer cases, and affected over 2.1 Million people in 2015 alone. 
                   It starts when cells in the breast begin to grow out of control. These cells usually form tumors that can be seen via X-ray or felt as lumps in the breast area.")
                )
              )
      ),
      tabItem(tabName = "description",
              fluidPage(
                titlePanel("Description of the Data"),
                sidebarLayout(
                  sidebarPanel(
                    h4("The dataset has 569 observations with 32 variables. 
                       However, after selecting features, we only used 9 predictor variables for further analysis.")
                  ),
                  mainPanel(
                    tabsetPanel(
                      tabPanel("Variables",
                               fluidRow(
                                 column(6,
                                        box(
                                          title = "Variables",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 280,
                                          height = 310,
                                          div(imageOutput("var"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        )
                                 )
                               )
                      ),
                      tabPanel("Glimpse", verbatimTextOutput("glimpse")),
                      tabPanel("Structure", verbatimTextOutput("structure"))
                    )
                  )
                )
              )
      ),
      tabItem(tabName = "summary",
              fluidPage(
                titlePanel("Summary of the Data"),
                sidebarLayout(
                  sidebarPanel(
                    h4("About the Data"),
                    selectInput("summary_feature", "Select Feature for Summary:", 
                                choices = colnames(data)[3:32])
                  ),
                  mainPanel(
                    tabsetPanel(
                      tabPanel("Summary Statistics", 
                               verbatimTextOutput("summary")),
                      tabPanel("Pie Chart",
                               plotOutput("pieChart"),
                               h4("Benign (B): 357 cases (62.7%)"),
                               h4("Malignant (M): 212 cases (37.3%)"),
                               h5("This distribution shows that the dataset is somewhat balanced with slightly more benign cases than malignant cases."))
                    )
                  )
                )
              )
      ),
      tabItem(tabName = "visualizations",
              fluidPage(
                titlePanel("Data Visualizations"),
                sidebarLayout(
                  sidebarPanel(
                    h3("Summary and Visualizations"),
                    selectInput("feature", "Select Feature for Several Plot:", 
                                choices = colnames(data)[3:32])
                  ),
                  mainPanel(
                    tabsetPanel(
                      tabPanel("Correlation Matrix", 
                               plotOutput("correlationPlot")),
                      tabPanel("Pairwise Plot",
                               fluidRow(
                                 column(11, plotOutput("pairwise1")),
                                 column(11, plotOutput("pairwise2")),
                                 column(11, plotOutput("pairwise3")),
                                 column(11, plotOutput("pairwise4")),
                                 column(11, plotOutput("pairwise5")),
                                 column(11, plotOutput("pairwise6"))
                               )),
                      tabPanel("Density Plot",
                               plotOutput("densityPlot")),
                      tabPanel("Box Plot",
                               plotOutput("boxPlot")),
                      tabPanel("Bar Plot",
                               plotOutput("barPlot"))
                    )
                  )
                )
              )
      ),
      tabItem(tabName = "scatter_plot",
              fluidPage(
                titlePanel("Interactive Scatter Plot"),
                sidebarLayout(
                  sidebarPanel(
                    selectInput("x_feature", "Select X Feature for Scatter Plot:", 
                                choices = colnames(data)[3:32], selected = "radius_mean"),
                    selectInput("y_feature", "Select Y Feature for Scatter Plot:", 
                                choices = colnames(data)[3:32], selected = "texture_mean")
                  ),
                  mainPanel(
                    plotlyOutput("scatterPlot")
                  )
                )
              )
      ),
      tabItem(tabName = "best_methods",
              fluidPage(
                titlePanel("Best Methods"),
                sidebarLayout(
                  sidebarPanel(
                    h3("Machine Learning Methods")
                  ),
                  mainPanel(
                    tabsetPanel(
                      tabPanel("Random Forest Classifier",
                               h4("Feature Importances"),
                               fluidRow(
                                 column(6,
                                        box(
                                          title = "Repeated Holdout",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 280,
                                          height = 310,
                                          div(imageOutput("rfc1"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        )),
                                 column(6,
                                        box(
                                          title = "K-Fold Cross Validation",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 280,
                                          height = 310,
                                          div(imageOutput("rfc2"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        )),
                               )
                      ),
                      tabPanel("Confusion Matrix",
                               h4("Best Confusion Matrix from KNN Method"),
                               fluidRow(
                                 column(6,
                                        box(
                                          title = "Repeated Holdout",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 280,
                                          height = 310,
                                          div(imageOutput("bcm1"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        )),
                                 column(6,
                                        box(
                                          title = "K-Fold Cross Validation",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 280,
                                          height = 310,
                                          div(imageOutput("bcm2"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        )),
                               )
                      ),
                      tabPanel("Comparison of Results",
                               h4("Model Comparison"),
                               fluidRow(
                                 column(6,
                                        box(
                                          title = "Best Method",
                                          status = "primary",
                                          solidHeader = TRUE,
                                          width = 350,
                                          height = 340,
                                          div(imageOutput("best"), style = "text-align:center;",
                                              style = "margin-bottom: -170px")
                                        ))
                               ),
                               h5("Considering the accuracy value with balanced data, 
                                  it was found that the model with the best performance for classifying breast cancer tissue biopsy 
                                  results in mothers was using K-Nearest Neighbors with the K-Fold Cross Validation data split method.")
                      )
                    )
                  )
                )
              )
      ),
      tabItem(tabName = "authors",
              fluidPage(
                titlePanel("Authors"),
                fluidRow(
                  column(6,
                         box(
                           title = "Author 1",
                           status = "primary",
                           solidHeader = TRUE,
                           width = 100,
                           div(imageOutput("au1"), style = "text-align:center;",
                               style = "margin-bottom: -170px"),
                           h4("Meysa Endies Irenia Putri"),
                           h5("5003211001")
                         )),
                  column(6,
                         box(
                           title = "Author 2",
                           status = "primary",
                           solidHeader = TRUE,
                           width = 100,
                           div(imageOutput("au2"), style = "text-align:center;",
                               style = "margin-bottom: -170px"),
                           h4("Chafshoh Nafilah"),
                           h5("5003211011")
                         )),
                  column(12, # Use the full width of the parent container
                         div(style = "display: flex; justify-content: center;",
                             column(6, # Set the width of the box
                                    box(
                                      title = "Author 3",
                                      status = "primary",
                                      solidHeader = TRUE,
                                      width = NULL,
                                      div(imageOutput("au3"), style = "text-align:center;",
                                          style = "margin-bottom: -170px"),
                                      h4("Salma Zaura Baraza"),
                                      h5("5003211151")
                                    )
                             )
                         )
                  )
                ),
                br(),
                div(style = "text-align:center; font-size: 20px; font-weight: bold;",
                    p("Departemen Statistika"),
                    p("Fakultas Sains dan Analitika Data"),
                    p("Institut Teknologi Sepuluh Nopember Surabaya"),
                    p("2024")
                )
              )
      )
    )
  )
)

# Define server logic
server <- function(input, output) {
  
  output$img1 <- renderImage({
    list(src = "bc.png", height = 200, width = 400)
  }, deleteFile = FALSE)
  
  output$au1 <- renderImage({
    list(src = "au1.jpg", height = 200, width = 150)
  }, deleteFile = FALSE)
  
  output$au2 <- renderImage({
    list(src = "au2.png", height = 200, width = 150)
  }, deleteFile = FALSE)
  
  output$au3 <- renderImage({
    list(src = "au3.jpg", height = 200, width = 135)
  }, deleteFile = FALSE)
  
  output$summary <- renderPrint({
    feature_data <- data[[input$summary_feature]]
    feature_type <- class(feature_data)
    summary_stats <- list(
      Summary = summary(feature_data),
      Type = feature_type,
      Mean = mean(feature_data, na.rm = TRUE),
      Median = median(feature_data, na.rm = TRUE),
      StdDev = sd(feature_data, na.rm = TRUE),
      Variance = var(feature_data, na.rm = TRUE),
      Min = min(feature_data, na.rm = TRUE),
      Max = max(feature_data, na.rm = TRUE),
      Range = range(feature_data, na.rm = TRUE),
      IQR = IQR(feature_data, na.rm = TRUE),
      Percentiles = quantile(feature_data, probs = c(0.25, 0.5, 0.75), na.rm = TRUE),
      Skewness = skewness(feature_data, na.rm = TRUE),
      Kurtosis = kurtosis(feature_data, na.rm = TRUE)
    )
    summary_stats
  })
  
  output$table <- renderTable({
    data %>% select(diagnosis) %>% table() %>% as.data.frame()
  })
  
  output$pieChart <- renderPlot({
    diagnosis_count <- data %>% count(diagnosis)
    diagnosis_count <- diagnosis_count %>%
      mutate(percentage = n / sum(n) * 100,
             label = paste0(diagnosis, ": ", n, " cases (", round(percentage, 1), "%)"))
    
    ggplot(diagnosis_count, aes(x = "", y = n, fill = diagnosis)) +
      geom_bar(stat = "identity", width = 1) +
      coord_polar("y", start = 0) +
      theme_void() +
      geom_text(aes(label = label), position = position_stack(vjust = 0.5)) +
      labs(fill = "Diagnosis", title = "Diagnosis Distribution") +
      theme(legend.position = "right")
  })
  
  output$correlationPlot <- renderPlot({
    data_numeric <- data %>% select(-id, -diagnosis)
    cor_matrix <- cor(data_numeric)
    corrplot(cor_matrix, method = "color", type = "upper", tl.col = "black", 
             tl.srt = 100, addCoef.col = "black", number.cex = 0.4)
  })
  
  output$pairwise1 <- renderPlot({
    ggscatmat(data, columns = 3:8, color = "diagnosis")
  })
  
  output$pairwise2 <- renderPlot({
    ggscatmat(data, columns = 9:14, color = "diagnosis")
  })
  
  output$pairwise3 <- renderPlot({
    ggscatmat(data, columns = 15:20, color = "diagnosis")
  })
  
  output$pairwise4 <- renderPlot({
    ggscatmat(data, columns = 21:26, color = "diagnosis")
  })
  
  output$pairwise5 <- renderPlot({
    ggscatmat(data, columns = 27:32, color = "diagnosis")
  })
  
  output$densityPlot <- renderPlot({
    ggplot(data, aes_string(x = input$feature, fill = "diagnosis")) +
      geom_density(alpha = 0.5) +
      labs(title = paste("Density Plot of", input$feature),
           x = input$feature,
           y = "Density") +
      theme_minimal()
  })
  
  output$boxPlot <- renderPlot({
    ggplot(data, aes_string(x = "diagnosis", y = input$feature, fill = "diagnosis")) +
      geom_boxplot(alpha = 0.5) +
      labs(title = paste("Box Plot of", input$feature, "by Diagnosis"),
           x = "Diagnosis",
           y = input$feature) +
      theme_minimal()
  })
  
  output$barPlot <- renderPlot({
    ggplot(data, aes_string(x = "diagnosis", y = input$feature, fill = "diagnosis")) +
      geom_bar(stat = "identity", alpha = 0.5) +
      labs(title = paste("Bar Plot of", input$feature, "by Diagnosis"),
           x = "Diagnosis",
           y = input$feature) +
      theme_minimal()
  })
  
  output$scatterPlot <- renderPlotly({
    plot_ly(data, x = ~get(input$x_feature), y = ~get(input$y_feature), color = ~diagnosis,
            type = "scatter", mode = "markers") %>%
      layout(title = paste("Scatter Plot of", input$x_feature, "vs", input$y_feature),
             xaxis = list(title = input$x_feature),
             yaxis = list(title = input$y_feature))
  })
  
  output$var <- renderImage({
    list(src = "variabel.png", height = 250, width = 300)
  }, deleteFile = FALSE)
  
  output$glimpse <- renderPrint({
    glimpse(data)
  })
  
  output$structure <- renderPrint({
    str(data)
  })
  
  # Random Forest Classifier and Confusion Matrix
  output$rfc1 <- renderImage({
    list(src = "rf_holdout_fi.png", height = 250, width = 300)
  }, deleteFile = FALSE)
  
  output$rfc2 <- renderImage({
    list(src = "rf_kfold_fi.png", height = 250, width = 300)
  }, deleteFile = FALSE)
  
  output$bcm1 <- renderImage({
    list(src = "cf_knn_holdout.png", height = 250, width = 300)
  }, deleteFile = FALSE)
  
  output$bcm2 <- renderImage({
    list(src = "cf_knn_kfold.png", height = 250, width = 300)
  }, deleteFile = FALSE)
  
  output$best <- renderImage({
    list(src = "comparison.png", height = 280, width = 330)
  }, deleteFile = FALSE)
  
}

# Run the application 
shinyApp(ui = ui, server = server)
